CashSMP Choice Crate Resource Pack

This changes the purple shulker box used by /crateplace choice into the Choice Crate design.

Install:
1. Upload this ZIP to a public direct HTTPS URL (GitHub release asset, CDN, or web host).
2. Put the direct URL in server.properties as resource-pack=...
3. Add the ZIP SHA-1 to resource-pack-sha1=... and restart the server.

The resource pack changes purple shulker boxes globally, so use purple shulkers only for Choice Crates on the server.
